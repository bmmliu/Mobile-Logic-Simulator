package com.company;

public class OutputPin extends Component{
    Port input;
    public OutputPin(){
        input = new Port(this.ID);
    }

    @Override
    public void calculate() {
        state = input.state();
    }

    @Override
    public Port[] getInputPorts() {
        return new Port[]{input};
    }

    @Override
    public Port[] getOutputPorts() {
        return new Port[]{};
    }

    @Override
    public boolean inputsAreConnected() {
        return input.isConnected();
    }
}
