package com.company;

public class Port {
    private boolean state;
    private int prevID;
    private int ID;
    private int parentComponentID;
    private static int idCount = 0;

    public Port() {
        idCount++;
        ID = idCount;
        state = false;
        prevID = -1;
    }

    public Port(int parentComponentID) {
        idCount++;
        ID = idCount;
        state = false;
        this.parentComponentID = parentComponentID;
        prevID = -1;
    }

    public int getID() {
        return ID;
    }

    public void setID(int id) {
        this.ID = id;
    }

    public int getPrevID() {
        return prevID;
    }

    public boolean state() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public int getParentComponentID() {
        return parentComponentID;
    }

    public void setParentComponentID(int parentComponentID) {
        this.parentComponentID = parentComponentID;
    }

    public void setPrevID(int prevID) {
        this.prevID = prevID;
    }

    public void disconnect() {
        prevID = -1;
    }

    public boolean isConnected() {
        return prevID != -1;
    }

}
