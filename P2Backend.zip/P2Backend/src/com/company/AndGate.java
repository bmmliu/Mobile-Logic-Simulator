package com.company;

public class AndGate extends Component {
    private Port input1, input2, output;

    public AndGate(){
        input1 = new Port(this.ID);
        input2 = new Port(this.ID);
        output = new Port(this.ID);
    }


    @Override
    public void calculate() {
        state = input1.state() && input2.state();
        output.setState(state);
    }

    @Override
    public Port[] getInputPorts() {
        return new Port[]{input1, input2};
    }

    public Port[] getOutputPorts(){
        return new Port[]{output};
    }

    @Override
    public boolean inputsAreConnected() {
        return input1.isConnected() && input2.isConnected();
    }
}
