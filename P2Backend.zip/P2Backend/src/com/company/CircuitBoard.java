package com.company;

import java.util.HashMap;


//True is 1, false is 0
public class CircuitBoard {
    //Map of Gates
    HashMap<Integer, Component> componentsMap;
    //Map of ports
    HashMap<Integer, Port> portsMap;
    //MAP OF INPUT PINS
    HashMap<Integer, InputPin> inputPinsMap;
    //MAP OF OUTPUT PINS
    HashMap<Integer, OutputPin> outputPinsMap;

    public CircuitBoard(){
        componentsMap = new HashMap<>();
        portsMap = new HashMap<>();
        inputPinsMap = new HashMap<>();
        outputPinsMap = new HashMap<>();
    }



    private void registerComponent(Component c){
        componentsMap.put(c.getID(), c);
        for(Port p: c.getInputPorts()){
            portsMap.put(p.getID(), p);
        }
        for(Port p: c.getOutputPorts()){
            portsMap.put(p.getID(), p);
        }
    }

    //FOR ALL ADDING METHODS, IDS ARE JUST FOR TESTING
    public void addAndGate(int id){
        AndGate andGate = new AndGate();
        andGate.setID(id);
        componentsMap.put(andGate.getID(), andGate);
        registerComponent(andGate);

    }

    public void addInputPin(int id){
        InputPin inputPin = new InputPin();
        inputPin.setID(id);
        inputPinsMap.put(inputPin.getID(), inputPin);
        registerComponent(inputPin);
    }

    public void addOutputPin(int id){
        OutputPin outputPin = new OutputPin();
        outputPin.setID(id);
        outputPinsMap.put(outputPin.getID(), outputPin);
        registerComponent(outputPin);
    }

    public void connectPorts(int id1, int id2){
        //Connect port 2 to port 1.
        portsMap.get(id2).setPrevID(id1);
    }

    public void disconnectPort(int id2){
        portsMap.get(id2).disconnect();
    }

    public boolean checkCircuit(){
        boolean connected = true;
        for(Component c: componentsMap.values()){
            if(!c.inputsAreConnected()){
                connected = false;
            }
        }
        return connected;
    }

    //METHOD THAT RUNS A SIMULATION. START FROM THE OUTPUT AND DO A DEPTH-FIRST TRAVERSAL.
    public void runSimulation(){
        if(!checkCircuit()){
            System.out.println("Circuit is invalid");
            return;
        }
        for(OutputPin outputPin: outputPinsMap.values()){
            calculateOutput(outputPin);
        }
    }

    private void calculateOutput(Component component){
        Port[] componentInputs = component.getInputPorts();
        while(componentInputs.length != 0){
            for(Port p: componentInputs){
                int prevID = p.getPrevID();
                Port prev = portsMap.get(prevID);
                int prevParentID = prev.getParentComponentID();
                calculateOutput(component);
            }
        }
        component.calculate();
    }



    public void test(){
        addInputPin(1);
        addInputPin(2);
        addAndGate(3);
        addOutputPin(4);

        connectPorts(1, 3);
        connectPorts(2, 4);
        connectPorts(5, 6);

        runSimulation();
    }
}
