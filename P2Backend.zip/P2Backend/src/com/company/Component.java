package com.company;

//FALSE = 0, TRUE = 1
public abstract class Component {
    private static int idCount = 0;
    protected int ID;
    protected boolean state;

    public Component(){
        idCount++;
        ID = idCount;
        state = false;
    }

    public int getID(){
        return ID;
    }

    //JUST FOR TESTING
    public void setID(int id){
        this.ID = id;
    }

    public abstract void calculate();

    public abstract Port[] getInputPorts();

    public abstract Port[] getOutputPorts();

    public abstract boolean inputsAreConnected();




}
