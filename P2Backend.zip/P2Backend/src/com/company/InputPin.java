package com.company;

public class InputPin extends Component{
    Port output;
    public InputPin(){
        output = new Port(this.ID);
        state = false;
    }

    @Override
    public void calculate() {
    }

    @Override
    public Port[] getInputPorts() {
        return new Port[]{};
    }

    @Override
    public Port[] getOutputPorts() {
        return new Port[]{output};
    }

    @Override
    public boolean inputsAreConnected() {
        //Obviously, since there are no inputs
        return true;
    }

    public void toggle(){
        state = !state;
    }
}
