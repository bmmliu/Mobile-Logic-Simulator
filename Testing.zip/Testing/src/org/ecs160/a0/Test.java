package org.ecs160.a0;

import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.plaf.Border;

public class Test extends Button {

    public Test(){
        //setDropTarget(true);
        setText("Drop Zone");
        this.getAllStyles().setBorder(Border.createLineBorder(10, 0x000000));
    }

    @Override
    public void drop(Component dragged, int x, int y) {
        System.out.println("Drop is called");
    }
}
