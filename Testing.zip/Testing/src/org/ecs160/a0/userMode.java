package org.ecs160.a0;

public class userMode {
}
