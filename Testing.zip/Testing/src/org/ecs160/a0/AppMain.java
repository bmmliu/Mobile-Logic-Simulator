package org.ecs160.a0;

import com.codename1.io.Storage;
import com.codename1.ui.*;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import java.io.IOException;

/**
 * Demo app showing how a simple poker card game can be written using Codename One, this
 * demo was developed for an <a href="http://www.sdjournal.org">SD Journal</a> article.
 * @author Shai Almog
 */

public class AppMain {
    private Form current;

    /**
     * This method is invoked by Codename One once when the application loads
     */
    public void init(Object context) {
        try{
            // after loading the default theme we load the card images as a resource with
            // a fake DPI so they will be large enough. We store them in a resource rather
            // than as files so we can use the MultiImage functionality
            Resources theme = Resources.openLayered("/theme");
            UIManager.getInstance().setThemeProps(theme.getTheme(theme.getThemeResourceNames()[0]));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is invoked by Codename One once when the application loads and when it is restarted
     */
    public void start() {
        if(current != null){
            current.show();
            return;
        }
        System.out.println("Simple Testing...");
        simpleTest();
        System.out.println("Simple Loading...");
        simpleLoad();
    }

    public void simpleTest() {
        String register = "Parent";

        Parent p = new Parent(45);
        p.printParent();

        save(register, p);

        System.out.println("After Saving Parent...");
        p.printParent();

        System.out.println("Updating Parent...");
        //Parent p2 = new Parent(p);
        p.setParent(33);
        p.printParent();
        //p2.printParent();

        System.out.println("Loading Parent...");
        //p = load(register);
        //Storage.getInstance().clearCache();

        p = load(register);
        p.printParent();
        System.out.println(p.c2.num);
    }

    public void simpleLoad() {
        String register = "Parent";

        Parent p = new Parent(45);
        p.printParent();

        System.out.println("Updating Parent...");
        p.setParent(33);
        p.printParent();

        System.out.println("Loading Parent...");
        p = load(register);
        p.printParent();
    }

    public static void save(String registerName, Parent p){
        Storage.getInstance().writeObject(registerName, new Parent(p));
    }

    public static Parent load(String registerName) {
        Parent p2 = (Parent)Storage.getInstance().readObject(registerName);
        p2.child = p2.c2;
        return p2;
    }

    public void stop() {
        current = Display.getInstance().getCurrent();
    }

    public void destroy() {
    }
}