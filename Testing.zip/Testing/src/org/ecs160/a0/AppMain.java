package org.ecs160.a0;

import com.codename1.ui.*;
import com.codename1.ui.animations.CommonTransitions;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.layouts.LayeredLayout;
import com.codename1.ui.layouts.mig.ComponentWrapper;
import com.codename1.ui.layouts.mig.Grid;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.ui.util.UITimer;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * Demo app showing how a simple poker card game can be written using Codename One, this
 * demo was developed for an <a href="http://www.sdjournal.org">SD Journal</a> article.
 * @author Shai Almog
 */

// TODO: Make this enum thing look more nice and pretty
enum UserMode {
    WIRE,
    DELETE,
    EDIT
}


public class AppMain {
    private Form current;

    // TODO: mode could be a global variable
    public static UserMode mode;
    public static Wire wire;

    /**
     * This method is invoked by Codename One once when the application loads
     */
    public void init(Object context) {
        try{
            // after loading the default theme we load the card images as a resource with
            // a fake DPI so they will be large enough. We store them in a resource rather
            // than as files so we can use the MultiImage functionality
            Resources theme = Resources.openLayered("/theme");
            UIManager.getInstance().setThemeProps(theme.getTheme(theme.getThemeResourceNames()[0]));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is invoked by Codename One once when the application loads and when it is restarted
     */
    public void start() {
        if(current != null){
            current.show();
            return;
        }

        simpleUserView();
        //simpleTest();
    }

    private void simpleTest() {
        Form appForm = new Form();
        appForm.setScrollable(false);
        //Container appLayout = new Container(new BorderLayout());
        Container appLayout = new Container(new GridLayout(1,2));
        appForm.addComponent(appLayout);

        //Button myButton = new Button("Button");
        //myButton.setDraggable(true);

        Slot DropZone = new Slot("P1");
        //Button myButton = t.getButton();

        Slot myButton = new Slot("empty");
        //Button DropZone = s.getButton();

        //Button DropZone = new dropButton();
        DropZone.setText("Drop Zone");
        //DropZone.setDropTarget(true);
        //appLayout.addComponent(BorderLayout.NORTH, myButton);
        //appLayout.addComponent(BorderLayout.CENTER, DropZone);
        appLayout.addComponent(myButton);
        appLayout.addComponent(DropZone);

        myButton.addDropListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                appForm.show();
            }
        });

        appForm.show();
    }

    // TODO: When deleting a gate, clear the connections and remove all the other lines as well
    private void simpleUserView() {
        // Create the Form and base Container of the application
        Form appForm = new Form();  // TODO: Let appForm be the circuitView Form
        appForm.setScrollable(false);
        Container appLayout = new Container(new BorderLayout());
        Container wireLayout = new Container(new LayeredLayout());
        mode = UserMode.EDIT;

        // New
        wire = new Wire(wireLayout);   // TODO: Remember, needs to add circuitView Form
        // End

        // For now, just put layout into form init as layeredlayout
        appForm.setLayout(new LayeredLayout());
        appForm.addComponent(wireLayout);
        appForm.addComponent(appLayout);

        // Create the circuitBoard and ButtonList components
        final Container circuitBoardContainer = new Container(new GridLayout(10, 10));
        final Container buttonListContainer = new Container(new GridLayout(1, 5));

        // Create 3 different types of components: empty, placeHolder1, and placeHolder2
        // Button pH1 and pH2 will be draggable
        ArrayList<Slot> slots = new ArrayList<Slot>();

        // To initalize the circuitBoard, place empty labels to all of them
        for (int i = 0; i < 100; i++) {
            slots.add(new Slot("empty"));
            Slot s = slots.get(slots.size()-1).getSlot();
            circuitBoardContainer.addComponent(s);
            s.setId(i);
            s.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent evt) {
                    evt.consume();

                    // We only let user edit the wire if there is component in it
                    if (mode == UserMode.WIRE && !s.isSlotType("empty")) {
                        //System.out.println("Add wire?");
                        // New
                        wire.addConnection(s);
                        appForm.show();
                        // End

                        // Technically we don't need to check if deleting slot is empty but just for consistency
                    } else if (mode == UserMode.DELETE && !s.isSlotType("empty")) {
                        s.emptySlot();
                        appForm.show();
                    }
                }
            });
        }

        // To initalize the buttonList, place 5 different buttons into them
        // The first button is for adding wire, which we will not have for now
        // This will switch all components to nondraggable
        Button wireEdit = new Button("Wire");

        // The second and third buttons are for PlaceHold objects,
        // and will create PlaceHolder object when clicked
        Button pH1Select = new Button("P1");
        Button pH2Select = new Button("P2");

        // The forth button let user delete unwanted components
        // This will switch all components to nondraggable
        Button trashCan = new Button ("Del");

        // The final button let user to move around the component
        // This will switch all appropriate components to draggable
        // Upon user clicking any buttons to add new gates, it wlll switch back to edit mode
        Button circuitEdit = new Button("Move");

        buttonListContainer.addComponent(wireEdit);
        buttonListContainer.addComponent(pH1Select);
        buttonListContainer.addComponent(pH2Select);
        buttonListContainer.addComponent(trashCan);
        buttonListContainer.addComponent(circuitEdit);

        appLayout.addComponent(BorderLayout.CENTER, circuitBoardContainer);
        appLayout.addComponent(BorderLayout.SOUTH, buttonListContainer);

        appForm.show();

        // When clicked "Wire" button, user can add wire to connect each gates
        // TODO: For now, "Wire" button make all components nondraggable to make them clickable
        wireEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                mode = UserMode.WIRE;
                disableDrag(slots);
            }
        });

        // When clicked P1/P2, object P1/P2 should be spawned at the first available slot
        pH1Select.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                mode = UserMode.EDIT;
                enableDrag(slots);
                for (int i = 0; i < slots.size(); i++) {
                    Slot s = slots.get(i);
                    if (s.isSlotType("empty")) {
                        s.setSlot("P1");
                        // New
                        s.addDragFinishedListener(new ActionListener() {
                        // End
                            @Override
                            public void actionPerformed(ActionEvent evt) {  // Correcting idenifiers and rearranging wires
                                for (int j = 0; j < slots.size(); j++) if (circuitBoardContainer.getComponentIndex(slots.get(j)) != slots.get(j).getId()) slots.get(j).setId(j);
                                // New
                                wire.rearrangeWire(s);
                                //System.out.println("Slot have been dropped");
                                appForm.show();
                                // End
                            }
                        });
                        break;
                    }
                }
                appForm.show();
            }
        });

        pH2Select.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                mode = UserMode.EDIT;
                enableDrag(slots);
                for (int i = 0; i < slots.size(); i++) {
                    Slot s = slots.get(i);
                    if (s.isSlotType("empty")) {
                        s.setSlot("P2");
                        // New
                        s.addDragFinishedListener(new ActionListener() {
                        // End
                            @Override
                            public void actionPerformed(ActionEvent evt) {  // Correcting idenifiers and rearranging wires
                                for (int j = 0; j < slots.size(); j++) if (circuitBoardContainer.getComponentIndex(slots.get(j)) != slots.get(j).getId()) slots.get(j).setId(j);
                                // New
                                wire.rearrangeWire(s);
                                //System.out.println("Slot have been dropped");
                                appForm.show();
                                // End
                            }
                        });
                        break;
                    }
                }
                appForm.show();
            }
        });

        // Trash can will enable user to delete object on click
        trashCan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                mode = UserMode.DELETE;
                disableDrag(slots);
            }
        });

        // Move will enable user to move object around
        circuitEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                evt.consume();
                mode = UserMode.EDIT;
                enableDrag(slots);
            }
        });
    }

    public void enableDrag(ArrayList<Slot> slots) {
        for (int i = 0; i < slots.size(); i++) {
            slots.get(i).turnOnDrag();
        }
    }

    public void disableDrag(ArrayList<Slot> slots) {
        for (int i = 0; i < slots.size(); i++) {
            slots.get(i).turnOffDrag();
        }
    }

    public Slot findSlot(ArrayList<Slot> slots, int id) {
        for (int i = 0; i < slots.size(); i++) {
            if (slots.get(i).getId() == id) {
                return slots.get(i);
            }
        }
        return null;
    }

    public void stop() {
        current = Display.getInstance().getCurrent();
    }

    public void destroy() {
    }
}