package org.ecs160.a0;

import com.codename1.io.Externalizable;
import com.codename1.io.Util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;

public class Parent implements Externalizable {
    //private static int num;
    private int num;
    //public ArrayList<Child> childs = new ArrayList<>();
    public static Child child;
    public Child c2;
    //public ArrayList<Integer> nums = new ArrayList<>();
    private String string;

    public Parent(int n) {
        num = n;
        string = Integer.toString(n);
        child = new Child();
        c2 = new Child();
    }

    public Parent(Parent p) {
        num = p.num;
        string = p.string;
        child = new Child(p.child);
        c2 = new Child(p.c2);
    }

    public int getNum() {
        return num;
    }

    public void setNum(int n) {
        num = n;
    }

    public String getString() {
        return string;
    }

    public void setString(String s) {
        string = s;
    }

    public void setParent(int n) {
        setNum(n);
        setString(Integer.toString(n));
        child.num = 89;
        c2.num = 89;
    }

    public void printParent() {
        System.out.println("New num: " + num);
        System.out.println("New string: " + string);
        System.out.println("New child: " + child.num);
        System.out.println("New c2: " + c2.num);
    }

    @Override
    public int getVersion() {
        return 1;
    }

    @Override
    public void externalize(DataOutputStream dataOutputStream) throws IOException {
        //System.out.println("Externalizing Parent...");
        dataOutputStream.writeInt(num);
        c2 = new Child(child);
        Util.writeObject(c2, dataOutputStream);
        Util.writeUTF(string, dataOutputStream);
    }

    static {Util.register("Parent", Parent.class);}

    @Override
    public void internalize(int i, DataInputStream dataInputStream) throws IOException {
        //System.out.println("Internalizing Parent...");
        num = dataInputStream.readInt();
        c2 = (Child)Util.readObject(dataInputStream);
        string = Util.readUTF(dataInputStream);
    }

    @Override
    public String getObjectId() {
        return "Parent";
    }

}
