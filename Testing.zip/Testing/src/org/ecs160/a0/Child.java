package org.ecs160.a0;

import com.codename1.io.Util;
import com.codename1.ui.Container;
import com.codename1.io.Externalizable;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/*
public class Child extends Container {
    public int num = 67;
}

 */
public class Child extends Container implements Externalizable {
    public int num = 67;

    public Child(){}

    public Child(Child c) {
        //if (c != null)
        num = c.num;
    }

    @Override
    public int getVersion() {
        return 0;
    }

    @Override
    public void externalize(DataOutputStream out) throws IOException {
        //System.out.println("Externalizing Child...");
        out.writeInt(num);
    }

    static {
        Util.register("Child", Child.class);}

    @Override
    public void internalize(int version, DataInputStream in) throws IOException {
        //System.out.println("Internalizing Child...");
        num = in.readInt();
        //System.out.println(num);
    }

    @Override
    public String getObjectId() {
        return "Child";
    }
}
